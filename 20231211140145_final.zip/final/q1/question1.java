public class PrinterQueue {
    private String[] queue;
    private int size;
    private static final int INITIAL_CAPACITY = 10;

    public PrinterQueue() {
        this.queue = new String[INITIAL_CAPACITY];
        this.size = 0;
    }

    public void enqueue(String printTask) {
        if (size == queue.length) {
            resize();
        }
        queue[size++] = printTask;
    }

    public String dequeue() {
        if (!isEmpty()) {
            String frontTask = queue[0];
            System.arraycopy(queue, 1, queue, 0, size - 1);
            queue[--size] = null;
            return frontTask;
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
            return null;
        }
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public String peek() {
        if (!isEmpty()) {
            return queue[0];
        } else {
            System.out.println("Queue is empty. Cannot peek.");
            return null;
        }
    }

    public void clear() {
        queue = new String[INITIAL_CAPACITY];
        size = 0;
    }

    private void resize() {
        int newCapacity = queue.length * 2;
        queue = Arrays.copyOf(queue, newCapacity);
    }

    public static void main(String[] args) {
        PrinterQueue printerQueue = new PrinterQueue();

        // Enqueue tasks
        printerQueue.enqueue("Task1");
        printerQueue.enqueue("Task2");
        printerQueue.enqueue("Task3");

        // Peek at the front task
        System.out.println("Peek: " + printerQueue.peek());

        // Dequeue tasks
        System.out.println("Dequeue: " + printerQueue.dequeue());
        System.out.println("Dequeue: " + printerQueue.dequeue());

        // Check if the queue is empty
        System.out.println("Is Empty: " + printerQueue.isEmpty());

        // Clear the queue
        printerQueue.clear();
        System.out.println("Is Empty after clear: " + printerQueue.isEmpty());
    }
}