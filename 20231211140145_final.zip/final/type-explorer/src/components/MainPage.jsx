import { Link } from "react-router-dom";

const MainPage = () => {
  return (
    <div className="container">
      <h1>Welcome</h1>
      <p>Name: Lakshman Badiga</p>
      <p>Student ID: 2130440</p>
      <div className="buttons">
        <Link to="/flowers">
          <button className="category-button">Flowers</button>
        </Link>
        <Link to="/trees">
          <button className="category-button">Trees</button>
        </Link>
        <Link to="/cars">
          <button className="category-button">Cars</button>
        </Link>
      </div>
    </div>
  );
};

export default MainPage;
