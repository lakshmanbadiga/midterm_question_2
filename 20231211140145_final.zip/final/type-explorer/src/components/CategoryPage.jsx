// CategoryPage.jsx
import PropTypes from "prop-types";

const CategoryPage = ({ category, models, bgColor }) => {
  return (
    <div
      className="container"
      style={{ backgroundColor: bgColor, color: "white" }}
    >
      <h2>{category}</h2>
      <ul>
        {models.map((item, index) => (
          <li key={index}>
            <strong>{item.name}</strong> - {item.info}
          </li>
        ))}
      </ul>
    </div>
  );
};

CategoryPage.propTypes = {
  category: PropTypes.string.isRequired,
  models: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      info: PropTypes.string.isRequired,
    })
  ).isRequired,
  bgColor: PropTypes.string.isRequired,
};

export default CategoryPage;
