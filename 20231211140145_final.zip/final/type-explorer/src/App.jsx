// App.jsx
import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainPage from "./components/MainPage";
import CategoryPage from "./components/CategoryPage";

import "./App.css";

function App() {
  const flowers = [
    { name: "Rose", info: "Symbol of love and beauty" },
    {
      name: "Sunflower",
      info: "Known for its large size and bright yellow color",
    },
    {
      name: "Tulip",
      info: "Comes in various colors and represents perfect love",
    },
    { name: "Daisy", info: "Simple and beautiful wildflower" },
    { name: "Lily", info: "Known for its elegant and fragrant flowers" },
  ];

  const trees = [
    { name: "Oak", info: "Known for its strength and durability" },
    { name: "Maple", info: "Famous for vibrant autumn colors" },
    { name: "Pine", info: "Evergreen tree with needle-like leaves" },
    { name: "Birch", info: "Recognized by its distinctive white bark" },
    {
      name: "Cherry Blossom",
      info: "Beautiful flowering tree, especially in spring",
    },
  ];

  const cars = [
    { name: "Sedan", info: "A passenger car with a closed body" },
    { name: "SUV", info: "Sport Utility Vehicle designed for off-road use" },
    {
      name: "Sports Car",
      info: "Designed for high-speed driving and maneuverability",
    },
    { name: "Truck", info: "Large vehicle designed for transporting goods" },
    { name: "Convertible", info: "Car with a roof that can be folded down" },
  ];

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route
          path="/flowers"
          element={
            <CategoryPage category="Flowers" models={flowers} bgColor="blue" />
          }
        />
        <Route
          path="/trees"
          element={
            <CategoryPage category="Trees" models={trees} bgColor="green" />
          }
        />
        <Route
          path="/cars"
          element={<CategoryPage category="Cars" models={cars} bgColor="red" />}
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
